# Mobile Banking App Prototype (Java + SQLite + REST Stub)

A minimal Android prototype demonstrating:
- **Account balance** display
- **Transfers** (client → mock REST → update local DB)
- **Transaction history** (SQLite)
- **Retrofit + OkHttp mock backend** (no server required)

## Tech
- Android (Java), Material Components
- SQLite via `SQLiteOpenHelper`
- Retrofit2 + OkHttp3 + Gson

## Quickstart (Android Studio)
1. **File → Open...** and select this folder.
2. Let Android Studio **Sync Gradle** (it will download the correct Gradle/AGP).
3. Run on an emulator or USB device (API 24+).

> If Studio asks to create a Gradle wrapper, accept the prompt.

## App Features
- **Accounts tab**: shows account number and current balance. Tap **Refresh** to fetch from the in-app mock REST.
- **Transfer tab**: enter beneficiary, amount, and optional note; on success, local DB balance is updated and a transaction row is inserted.
- **History tab**: shows transactions from local SQLite, newest first.

## Structure
```
app/
  src/main/
    java/com/example/mobilebank/...
    res/layout/...
    res/menu/bottom_nav_menu.xml
    AndroidManifest.xml
build.gradle (Project)
app/build.gradle (Module)
settings.gradle
```

## Notes
- Money is stored as `double` for brevity—use `BigDecimal` in production.
- The mock backend lives in `MockInterceptor` and keeps an in-memory `balance` only while the app process lives.
- This is a **prototype** to practice mobile dev, local DB, and client–server calls.

## License
MIT
