package com.example.mobilebank.data.models;

public class BankTransaction {
    public long id;
    public String accountNumber;
    public String beneficiary;
    public double amount;
    public String note;
    public long timestamp;
}
