package com.example.mobilebank.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.mobilebank.R;
import com.example.mobilebank.data.BankingRepository;
import com.example.mobilebank.data.models.Account;
import com.example.mobilebank.data.models.BankTransaction;
import com.example.mobilebank.data.models.TransferRequest;
import com.example.mobilebank.network.ApiClient;
import com.example.mobilebank.network.ApiService;
import com.example.mobilebank.data.models.ApiResponse;

import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TransferFragment extends Fragment {
    private EditText etBeneficiary, etAmount, etNote;
    private TextView tvStatus;
    private BankingRepository repo;
    private ApiService api;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_transfer, container, false);
        etBeneficiary = v.findViewById(R.id.etBeneficiary);
        etAmount = v.findViewById(R.id.etAmount);
        etNote = v.findViewById(R.id.etNote);
        tvStatus = v.findViewById(R.id.tvTransferStatus);
        Button btn = v.findViewById(R.id.btnTransfer);

        repo = new BankingRepository(requireContext());
        api = ApiClient.get();

        btn.setOnClickListener(view -> doTransfer());
        return v;
    }

    private void doTransfer() {
        String beneficiary = etBeneficiary.getText().toString().trim();
        String amtStr = etAmount.getText().toString().trim();
        String note = etNote.getText().toString().trim();

        if (TextUtils.isEmpty(beneficiary) || TextUtils.isEmpty(amtStr)) {
            tvStatus.setText("Enter beneficiary and amount");
            return;
        }
        double amount = Double.parseDouble(amtStr);
        if (amount <= 0) {
            tvStatus.setText("Amount must be positive");
            return;
        }

        Account a = repo.getAccount();
        if (a == null) return;

        TransferRequest req = new TransferRequest(a.accountNumber, beneficiary, amount, note);
        api.transfer(req).enqueue(new Callback<ApiResponse<java.util.Map<String, Object>>>() {
            @Override public void onResponse(Call<ApiResponse<java.util.Map<String, Object>>> call, Response<ApiResponse<java.util.Map<String, Object>>> response) {
                if (!response.isSuccessful() || response.body()==null) {
                    tvStatus.setText("Network error");
                    return;
                }
                if (response.body().success) {
                    java.util.Map<String, Object> data = response.body().data;
                    double newBal = (data!=null && data.get("newBalance")!=null) ? ((Number) data.get("newBalance")).doubleValue() : (a.balance - amount);
                    repo.updateBalance(a.accountNumber, newBal);

                    BankTransaction tx = new BankTransaction();
                    tx.accountNumber = a.accountNumber;
                    tx.beneficiary = beneficiary;
                    tx.amount = -amount;
                    tx.note = note;
                    tx.timestamp = System.currentTimeMillis()/1000L;
                    repo.insertTransaction(tx);

                    tvStatus.setText("Transfer successful. New balance: ₹" + String.format("%.2f", newBal));
                } else {
                    tvStatus.setText(response.body().message);
                }
            }
            @Override public void onFailure(Call<ApiResponse<java.util.Map<String, Object>>> call, Throwable t) {
                tvStatus.setText("Failed: " + t.getMessage());
            }
        });
    }
}
