package com.example.mobilebank.network;

import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.Protocol;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.Request;
import okio.Buffer;

import java.io.IOException;

public class MockInterceptor implements Interceptor {
    private double balance = 10000.0;

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request request = chain.request();
        String path = request.url().encodedPath();
        String method = request.method();

        String json;
        int code = 200;

        if (method.equals("GET") && path.matches("/api/accounts/\d+/balance")) {
            json = "{"success":true,"message":"OK","data":{"balance":" + balance + "}}";
        } else if (method.equals("POST") && path.equals("/api/transfer")) {
            String bodyStr = "";
            if (request.body() != null) {
                Buffer buffer = new Buffer();
                request.body().writeTo(buffer);
                bodyStr = buffer.readUtf8();
            }
            double amount = 0;
            String marker = ""amount":";
            int i = bodyStr.indexOf(marker);
            if (i >= 0) {
                int j = bodyStr.indexOf(',', i + marker.length());
                String num = (j>0? bodyStr.substring(i + marker.length(), j): bodyStr.substring(i + marker.length())).replaceAll("[^0-9.]+", "");
                try { amount = Double.parseDouble(num); } catch (Exception ignored) {}
            }
            if (amount <= 0) {
                json = "{"success":false,"message":"Invalid amount"}";
            } else if (amount > balance) {
                json = "{"success":false,"message":"Insufficient funds"}";
            } else {
                balance -= amount;
                json = "{"success":true,"message":"Transfer completed","data":{"newBalance":" + balance + "}}";
            }
        } else if (method.equals("GET") && path.matches("/api/accounts/\d+/transactions")) {
            json = "{"success":true,"message":"OK","data":{}}";
        } else {
            code = 404;
            json = "{"success":false,"message":"Not found"}";
        }

        return new Response.Builder()
                .code(code)
                .message("OK")
                .request(request)
                .protocol(Protocol.HTTP_1_1)
                .body(ResponseBody.create(MediaType.get("application/json"), json))
                .build();
    }
}
