package com.example.mobilebank.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.mobilebank.data.models.Account;
import com.example.mobilebank.data.models.BankTransaction;

import java.util.ArrayList;
import java.util.List;

public class BankingRepository {
    private final AppDatabaseHelper helper;

    public BankingRepository(Context ctx) {
        helper = new AppDatabaseHelper(ctx);
    }

    public Account getAccount() {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id, accountNumber, balance FROM accounts LIMIT 1", null);
        Account a = null;
        if (c.moveToFirst()) {
            a = new Account();
            a.id = c.getLong(0);
            a.accountNumber = c.getString(1);
            a.balance = c.getDouble(2);
        }
        c.close();
        return a;
    }

    public void updateBalance(String accountNumber, double newBalance) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("balance", newBalance);
        db.update("accounts", v, "accountNumber=?", new String[]{accountNumber});
    }

    public void insertTransaction(BankTransaction tx) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("accountNumber", tx.accountNumber);
        v.put("beneficiary", tx.beneficiary);
        v.put("amount", tx.amount);
        v.put("note", tx.note);
        v.put("timestamp", tx.timestamp);
        db.insert("transactions", null, v);
    }

    public List<BankTransaction> getTransactions(String accountNumber) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id, accountNumber, beneficiary, amount, note, timestamp FROM transactions WHERE accountNumber=? ORDER BY timestamp DESC", new String[]{accountNumber});
        List<BankTransaction> list = new ArrayList<>();
        while (c.moveToNext()) {
            BankTransaction t = new BankTransaction();
            t.id = c.getLong(0);
            t.accountNumber = c.getString(1);
            t.beneficiary = c.getString(2);
            t.amount = c.getDouble(3);
            t.note = c.getString(4);
            t.timestamp = c.getLong(5);
            list.add(t);
        }
        c.close();
        return list;
    }
}
