package com.example.mobilebank.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mobilebank.R;
import com.example.mobilebank.data.BankingRepository;
import com.example.mobilebank.data.models.Account;
import com.example.mobilebank.data.models.BankTransaction;

import java.util.List;

public class HistoryFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_history, container, false);
        RecyclerView rv = v.findViewById(R.id.rvTransactions);
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));

        BankingRepository repo = new BankingRepository(requireContext());
        Account a = repo.getAccount();
        java.util.List<BankTransaction> list = repo.getTransactions(a.accountNumber);
        rv.setAdapter(new com.example.mobilebank.ui.TransactionAdapter(list));
        return v;
    }
}
