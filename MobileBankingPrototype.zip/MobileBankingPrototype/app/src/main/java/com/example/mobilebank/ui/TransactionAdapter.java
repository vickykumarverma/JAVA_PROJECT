package com.example.mobilebank.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mobilebank.R;
import com.example.mobilebank.data.models.BankTransaction;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.VH> {
    private final List<BankTransaction> items;

    public TransactionAdapter(List<BankTransaction> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_transaction, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        BankTransaction t = items.get(pos);
        h.title.setText((t.amount < 0 ? "Debit to " : "Credit from ") + t.beneficiary);
        h.subtitle.setText(new SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(new Date(t.timestamp * 1000)) + (t.note==null||t.note.isEmpty()?"":" • " + t.note));
        h.amount.setText((t.amount < 0 ? "-₹" : "+₹") + String.format(Locale.getDefault(),"%.2f", Math.abs(t.amount)));
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView title, subtitle, amount;
        VH(@NonNull View v) { super(v); title = v.findViewById(R.id.tvTxTitle); subtitle = v.findViewById(R.id.tvTxSubtitle); amount = v.findViewById(R.id.tvTxAmount);}    
    }
}
