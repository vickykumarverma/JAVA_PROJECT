package com.example.mobilebank.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.mobilebank.R;
import com.example.mobilebank.data.BankingRepository;
import com.example.mobilebank.data.models.Account;
import com.example.mobilebank.network.ApiClient;
import com.example.mobilebank.network.ApiService;

import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AccountsFragment extends Fragment {
    private TextView tvAcc, tvBalance;
    private BankingRepository repo;
    private ApiService api;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_accounts, container, false);
        tvAcc = v.findViewById(R.id.tvAccountNumber);
        tvBalance = v.findViewById(R.id.tvBalance);
        Button btnRefresh = v.findViewById(R.id.btnRefresh);

        repo = new BankingRepository(requireContext());
        api = ApiClient.get();

        Account a = repo.getAccount();
        if (a != null) {
            tvAcc.setText("Account: " + a.accountNumber);
            tvBalance.setText("₹" + String.format("%.2f", a.balance));
        }

        btnRefresh.setOnClickListener(view -> refreshBalance());
        return v;
    }

    private void refreshBalance() {
        Account a = repo.getAccount();
        if (a == null) return;
        api.getBalance(a.accountNumber).enqueue(new Callback<com.example.mobilebank.data.models.ApiResponse<java.util.Map<String, Double>>>() {
            @Override public void onResponse(Call<com.example.mobilebank.data.models.ApiResponse<java.util.Map<String, Double>>> call, Response<com.example.mobilebank.data.models.ApiResponse<java.util.Map<String, Double>>> response) {
                if (response.isSuccessful() && response.body()!=null && response.body().success) {
                    java.util.Map<String, Double> data = response.body().data;
                    double bal = data.get("balance");
                    repo.updateBalance(a.accountNumber, bal);
                    tvBalance.setText("₹" + String.format("%.2f", bal));
                }
            }
            @Override public void onFailure(Call<com.example.mobilebank.data.models.ApiResponse<java.util.Map<String, Double>>> call, Throwable t) { }
        });
    }
}
