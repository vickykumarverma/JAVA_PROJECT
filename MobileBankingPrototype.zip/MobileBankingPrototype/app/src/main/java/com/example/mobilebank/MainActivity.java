package com.example.mobilebank;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.mobilebank.ui.AccountsFragment;
import com.example.mobilebank.ui.HistoryFragment;
import com.example.mobilebank.ui.TransferFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNav = findViewById(R.id.bottom_nav);
        bottomNav.setOnItemSelectedListener(item -> {
            Fragment f;
            int id = item.getItemId();
            if (id == R.id.nav_accounts) f = new AccountsFragment();
            else if (id == R.id.nav_transfer) f = new TransferFragment();
            else f = new HistoryFragment();
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, f)
                    .commit();
            return true;
        });

        bottomNav.setSelectedItemId(R.id.nav_accounts);
    }
}
