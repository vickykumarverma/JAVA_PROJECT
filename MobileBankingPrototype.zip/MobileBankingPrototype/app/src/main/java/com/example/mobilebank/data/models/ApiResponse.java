package com.example.mobilebank.data.models;

public class ApiResponse<T> {
    public boolean success;
    public String message;
    public T data;
}
