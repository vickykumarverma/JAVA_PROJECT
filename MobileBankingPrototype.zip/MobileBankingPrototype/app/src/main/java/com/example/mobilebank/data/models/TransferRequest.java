package com.example.mobilebank.data.models;

public class TransferRequest {
    public String fromAccount;
    public String toAccount;
    public double amount;
    public String note;

    public TransferRequest(String from, String to, double amount, String note) {
        this.fromAccount = from;
        this.toAccount = to;
        this.amount = amount;
        this.note = note;
    }
}
