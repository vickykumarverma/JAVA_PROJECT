package com.example.mobilebank.network;

import com.example.mobilebank.data.models.ApiResponse;
import com.example.mobilebank.data.models.TransferRequest;
import java.util.Map;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface ApiService {
    @GET("/api/accounts/{account}/balance")
    Call<ApiResponse<Map<String, Double>>> getBalance(@Path("account") String account);

    @POST("/api/transfer")
    Call<ApiResponse<Map<String, Object>>> transfer(@Body TransferRequest request);

    @GET("/api/accounts/{account}/transactions")
    Call<ApiResponse<Map<String, Object>>> getTransactions(@Path("account") String account);
}
