package com.example.mobilebank.data.models;

public class Account {
    public long id;
    public String accountNumber;
    public double balance;
}
