package com.example.mobilebank.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AppDatabaseHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "mobilebank.db";
    private static final int DB_VERSION = 1;

    public AppDatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE accounts (id INTEGER PRIMARY KEY AUTOINCREMENT, accountNumber TEXT UNIQUE, balance REAL)");
        db.execSQL("CREATE TABLE transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, accountNumber TEXT, beneficiary TEXT, amount REAL, note TEXT, timestamp INTEGER)");

        db.execSQL("INSERT INTO accounts (accountNumber, balance) VALUES ('1234567890', 10000.0)");
        db.execSQL("INSERT INTO transactions (accountNumber, beneficiary, amount, note, timestamp) VALUES ('1234567890','9876543210',-500.0,'Groceries',strftime('%s','now'))");
        db.execSQL("INSERT INTO transactions (accountNumber, beneficiary, amount, note, timestamp) VALUES ('1234567890','9876543210',2000.0,'Salary',strftime('%s','now'))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS transactions");
        db.execSQL("DROP TABLE IF EXISTS accounts");
        onCreate(db);
    }
}
